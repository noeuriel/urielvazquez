% captura de temperatura en timpo real con arduino y tres sensores


%% Apertura del seri (COM)

%borrar previos
delate(instrfind({'Port'},{'COM4'}));
%crear objeto  serie
a = serial('COM4','BaudRate',9600,'Terminator','CR/LF');
warning('off','MATLAB:serial:fscanf:unsuccessfulRead');
%abrir puerto
fopen(s);

%% Preparar medida

% parametros de medida
tmax = 100; % tiempo de captura en s
rate = 33; % resultado exprimental (comprobar)
